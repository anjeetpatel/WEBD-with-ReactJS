import React from 'react';
import Userlist from './components/Userlist';

export default function App() {
    const users = [
        { name: "Sreeraj", age: 19, email: "Sreeraj@gmail.com" },
        { name: "Satya", age: 19, email: "Satya@gmail.com" },
        { name: "Deva", age: 19, email: "Deva@gmail.com" },
        { name: "Yaswanth", age: 19, email: "Yaswanth@gmail.com" },
        { name: "Lohith", age: 19, email: "Lohith@gmail.com" },
    ];

    return (
        <Userlist 
            user1={users[0]} 
            user2={users[1]} 
            user3={users[2]} 
            user4={users[3]} 
            user5={users[4]} 
        />
    );
}
