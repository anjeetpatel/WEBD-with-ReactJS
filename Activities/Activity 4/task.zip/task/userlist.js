import React from "react";
import UserProfile from "./Userprofile";

export default function Userlist(props) {
    function updateProfile(user) {
        document.getElementById("profile-name").innerText = `Name: ${user.name}`;
        document.getElementById("profile-age").innerText = `Age: ${user.age}`;
        document.getElementById("profile-email").innerText = `Email: ${user.email}`;
    }

    return (
        <>
            <ul>
                <li onClick={() => updateProfile(props.user1)}>{props.user1.name}</li>
                <li onClick={() => updateProfile(props.user2)}>{props.user2.name}</li>
                <li onClick={() => updateProfile(props.user3)}>{props.user3.name}</li>
                <li onClick={() => updateProfile(props.user4)}>{props.user4.name}</li>
                <li onClick={() => updateProfile(props.user5)}>{props.user5.name}</li>
            </ul>
            <UserProfile />
        </>
    );
}
