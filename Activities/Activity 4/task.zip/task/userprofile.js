import React from "react";

export default function UserProfile() {
    return (
        <div>
            <h2>User Profile</h2>
            <p id="profile-name">Name: </p>
            <p id="profile-age">Age: </p>
            <p id="profile-email">Email: </p>
        </div>
    );
}
