import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import { useEffect } from 'react';
import UserCard from './components/userCard';

function App() {

  const [users, setUsers] = useState([]);

  useEffect(() => {
    const fetchUsers = async () => {
      try {

      const resp = await fetch('https://jsonplaceholder.typicode.com/users');
      const users = await resp.json();
      setUsers(users);
      }
      catch(err) {
        console.log(err);
      }
    }

    fetchUsers();
  }, []);

  function serachUsers(e) {
  
    console.log("called", e.target.value);
    const filteredUsers = users.filter(user => {
      return user.name.toLowerCase().includes(e.target.value.toLowerCase());
    });

    console.log("filetered users", filteredUsers);

    setUsers(filteredUsers);
  }
  return (
    <>
      {/*  check if the users are empty */}
      {users.length === 0 && <p>No users found</p>}

      <div>
        <input type="text" placeholder='search for users' onChange={serachUsers}/>
      </div>

      <div>
      </div>

      {/*  check if the users are not empty */}
      {users.length > 0 && (
        <div className="user-list">
          {users.map((user) => (
            <UserCard key={user.id} user={user} />
          ))}
        </div>)}
    </>
  )
}

export default App
