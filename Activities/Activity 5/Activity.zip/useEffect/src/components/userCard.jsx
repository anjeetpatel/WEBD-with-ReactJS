export default function UserCard(user) {
    console.log(user);
    return (
        <>
        <div className="user-card">
            <h1>{user.user.name}</h1>
            <p>{user.user.email}</p>
            <p>{user.user.phone}</p>
        </div>
        </>
    );
}